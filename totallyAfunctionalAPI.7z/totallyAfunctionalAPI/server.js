//to start-->node server.js

//every time the server starts default data is in the array
//---for initialization
const express = require ('express') //require to install express, npm install express
const app =  express()
const port = 3000

//---middleware
app.use(express.json()) //bodyparser


//--array
let job1 = {"id": "1", "title": "number one", "status": "always here"}
let sampleArray = [job1, {"id": "2", "title": "default", "status": "present"}]




//----routes


//localhost default message
app.get('/', function(){    //while server is on write ona  url localhost http://localhost:3000/ the console will receive a default message as response
    console.log('default message')
})

//get all method
app.get('/tasks', function(req, res){ //while server is on write ona  url localhost http://localhost:3000/tasks/"id number" to verify it works
sampleArray.get
res.send('Loaded');
console.log(sampleArray)
})

//get method
app.get('/tasks/:id', function(req, res){//while server is on write ona  url localhost http://localhost:3000/tasks to verify it works
    let id = sampleArray.params.id
    sampleArray.get[id]
    
})

//post method
app.post('/tasks', function(req, res){
sampleArray.push(req.body.newValue);
res.send('Submitted!');         //while server is on write ona  url localhost http://localhost:3000/tasks to verify it works
console.log(sampleArray)
})

//update method

app.patch('/tasks/:id', function(req, res){     //while server is on write ona  url localhost http://localhost:3000/tasks/"id number" to verify it works
    let value = req.params.newValue        
    let id = req.params.id
    sampleArray[id] = value 
res.send('Update')
})

//delete method
app.delete('tasks/:id', function(req, res){
    
    let id = req.params.id
        sampleArray.splice[id,1]
res.send('Deleted')
})



//startup message
app.listen(port, function(){
    console.log('Online')
})